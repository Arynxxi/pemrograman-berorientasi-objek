public class ClassVariabel {

    public static void main(String[] args) {

        int num = 15;
        float pecahan = 5.99f;
        char huruf = 'S';
        boolean logika = true;
        String kalimat = "Hello";

        System.out.println(num);
        System.out.println(pecahan);
        System.out.println(huruf);
        System.out.println(logika);
        System.out.println(kalimat);

    }

}
