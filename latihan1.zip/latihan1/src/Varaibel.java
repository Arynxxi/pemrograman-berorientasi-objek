public class Varaibel {

    public static void main(String[] args) {

        String nama1 = "Ahmad ";
        String nama2 = "Bukhari";

        System.out.println(nama1 + nama2);

    }

}
