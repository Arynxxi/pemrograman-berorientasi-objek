public class dataPenjualan {

    private String kode, nama, no;
    private Integer harga, stok;

    public dataPenjualan() {



    }
    public void setNama(String nama) {

        this.nama = nama;

    }
    public String getNama() {

        return nama;

    }


    public void setKode(String kode) {

        this.kode = kode;

    }
    public String getKode() {

        return kode;

    }


    public void setHarga(Integer harga) {

        this.harga = harga;

    }
    public Integer getharga() {

        return harga;

    }


    public void setStok(Integer stok) {

        this.stok = stok;

    }
    public Integer getStok() {

        return stok;

    }


}
