import java.sql.Statement;

public class Connection {

    private Connection connection;
    private Statement script;



}
